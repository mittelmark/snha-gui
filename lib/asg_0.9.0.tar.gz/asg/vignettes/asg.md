---
title: "Tutorial on the asg package - Network construction using the St. Nicolas House Algorithm"
shorttitle: "asg package tutorial"
author: Detlef Groth, University of Potsdam, Germany
date: 2021-10-21
abstract: >
    The *asg* package provides an easy to use interface to apply the St. Nicolas House Algorithm which traces associations chains between interactiving variables.
    In this package vignette the basic workflow for analyzing raw data or for analysing correlation matrices is demonstrated.
bibliography: bibliography.bib
csl: nature-biotechnology.csl

documentclass: scrartcl
geometry:
- top=20mm
- bottom=35mm
- left=20mm
- right=20mm
vignette: >
  %\VignetteEngine{knitr::rmarkdown}
  %\VignetteIndexEntry{pkgname}
  %\usepackage[utf8]{inputenc}
---

## Introduction

The package _asg_ explores interacting variables by searching association
chains, so where correlation coefficient drop in a regular oder between the
nodes. The package can be easily used by calling the function _asg.new_ with
your data, where the columns must be your variables. The return value is an
object of class _asg_ which has a plot function. The detailed analysis can be
inspected by looking at the internal variables of this object. Below a minimal
analysis. The variables are:

* _age_ - mother's age in years.
* _lwt_ - mother's weight in pounds at last menstrual period.
* _race_ - mother's race (1 = white, 2 = black, 3 = other).
* _smoke_ - smoking status during pregnancy (0 = no, 1 = yes).
* _ptl_ - number of previous premature labours.
* _ht_ - history of hypertension (0 = no, 1 = yes).
* _ui_ - presence of uterine irritability (0 = no, 1 = yes).
* _ftv_ -number of physician visits during the first trimester.
* _bwt_ birth weight of child in grams.



```r
par(mfrow=c(1,2),mai=c(0.8,0.8,0.1,0.2))
set.seed(125)
# retrieve some data
library(MASS)
data(birthwt)
birthwt$low=NULL # remove column
rnd=round(rnorm(nrow(birthwt),mean=10,sd=2),2)
birthwt=cbind(birthwt,rnd=rnd) # adding a random var
head(birthwt)
```

```
##    age lwt race smoke ptl ht ui ftv  bwt   rnd
## 85  19 182    2     0   0  0  1   0 2523 11.87
## 86  33 155    3     0   0  0  0   3 2551  8.95
## 87  20 105    1     1   0  0  0   1 2557 13.63
## 88  21 108    1     1   0  0  1   2 2594 10.17
## 89  18 107    1     1   0  0  1   0 2600 10.79
## 91  21 124    3     0   0  0  0   0 2622  5.61
```

```r
# analysis - spearman is safer than pearson, alpha = 0.1 is OK
# as the algorithm is robust agains spurious associations
library(asg)
pca=prcomp(t(scale(birthwt)))
asg.pcaplot(pca)
as=asg.new(birthwt,method="spearman",alpha=0.1) 
par(mai=c(0.8,0.2,0.1,0.2))
plot(as,layout="sam",vertex.size=7,lwd=3,edge.width=3)
box()
```

![Birth weight data variable interactions](figure/unnamed-chunk-1-1.png)

As you can see the variables in this simple graphs show immeadiatley logical
interaction, the birth weight is positively associated to mothers last weight,
and negatively to smoking, premature labours and iterine irritabilty, white
people smoke more and white mothers visit more often physicians ... The older
the mother the more visits at physicians and hpertension is positively
associated with weight of the mother.

What are the r-square values, prediction power for every node based on linear models and what are the connections:


```r
round(asg.rsquare(as),2)
```

```
##   age   lwt  race smoke   ptl    ht    ui   ftv   bwt   rnd 
##  0.05  0.12  0.15  0.18  0.02  0.06  0.08  0.05  0.13  0.00
```

```r
as$theta
```

```
##       age lwt race smoke ptl ht ui ftv bwt rnd
## age     0   0    0     0   0  0  0   1   0   0
## lwt     0   0    1     0   0  1  0   0   1   0
## race    0   1    0     1   0  0  0   1   0   0
## smoke   0   0    1     0   0  0  0   0   1   0
## ptl     0   0    0     0   0  0  0   0   1   0
## ht      0   1    0     0   0  0  0   0   0   0
## ui      0   0    0     0   0  0  0   0   1   0
## ftv     1   0    1     0   0  0  0   0   0   0
## bwt     0   1    0     1   1  0  1   0   0   0
## rnd     0   0    0     0   0  0  0   0   0   0
```

It can be seen that the overal strength of the association is very small,
largest r-square value is 0.18 for smoke, but still the analysis show reasonable
results without having the necessity of finding the right threshold.

## Installation

As long as the package is not yet on the CRAN repository the package can be
usually installed using the submitted tar.gz Archiv with the following
commands:

```
library(tcltk)
pkgname=tclvalue(tkgetOpenFile(
    filetypes="{{Tar.gz files} {*.tar.gz}} {{All files} {*.*}}"))
if (pkgname != "") {
    install.packages(pkgname,repos=NULL)
}
```


## Concept

Analyzing multivariate data is often done using visualization of pairwise
correlations, principal component analysis or multidimensional scaling are
typical methods in this area. The asg package provides an alternative
approach, by uncovering ordered sequences of correlation coefficients which
can be reversed [@Groth2019] [@Hermanussen2021]. Existing chains are translated
into edges between the variables here taken as nodes of a graph. The graph can
be then visualized and the major relations between the variables are visible.

The basic assumption of the method is the assumption that variables
correlations coefficients between two variables were one influences the other
are larger than those of secondary associations. So for instance if we assuem
that a variable A influences a variable B, and B influences C, it can be
assumed, that r(AB) > r(AC) and that in the opposite direction r(CB)> r(CA).
The algorithm provided in the asg package uncovers such association chains
where the order of correlation coefficient can be reversed. The advantage of
the method is that there is only a very limited requirement for choosing
thresholds for instance for the p-value or for the correlation coefficient.
The reason is that the existence of such association chains with the correct
ordering of three or more nodes is much less likely to exists by accident then
signficant pairwise correlations.

In the following we will first illustrate the concept on a simple hypothetical
association chain and thereafter show exemplarily the analysis on two well
known example datasets.

## Simple association chain


Let's assume we have a simple association chain where a variable A is
influecning a variable B, B is influencing a variable C and C is influencing
variable D. 


```r
par(mai=c(0.1,0.1,0.1,0.0))
plot(1,xlab="",ylab="",axes=FALSE,type="n",xlim=c(0.5,4.5),ylim=c(0.8,1.2))
arrows(1:3,rep(1,3),1:3+0.8,rep(1,3),lwd=3,length=0.1)
points(1:4,rep(1,4),pch=19,col="salmon",cex=6)
text(1:4,1,LETTERS[1:4],cex=2)
```

![An association chain](figure/start-1.png)

In this situation we can assume that, due to the omnipresent noise in such
situation, the correlations of directly interacting variables is higher in
comparison to variables only connected only via other variables. Let's assume
for simplicity reasons, that the correlation between directly connected
variables drops down from r=0.7 to around r=0.5 for secondary connected
variables and r=0.3 for tertiary connected variables. So a possible correlation matrix could lokk like this:


```r
C=matrix(c(1,0.7,0.5,0.3,
           0.7,1,0.7,0.5,
           0.5,0.7,1,0.7,
           0.3,0.5,0.7,1),
           nrow=4,byrow=TRUE)
rownames(C)=colnames(C)=LETTERS[1:4]           
knitr::kable(C)
```



|   |   A|   B|   C|   D|
|:--|---:|---:|---:|---:|
|A  | 1.0| 0.7| 0.5| 0.3|
|B  | 0.7| 1.0| 0.7| 0.5|
|C  | 0.5| 0.7| 1.0| 0.7|
|D  | 0.3| 0.5| 0.7| 1.0|

Let's now add a little bit of noise and visualize the pairwise correlations
using the plot function of the asg package.


```r
set.seed(123)
par(mfrow=c(1,2),mai=c(0.1,0.1,0.1,0.1))
C=C+rnorm(length(C),mean=0,sd=0.1)
C[lower.tri(C)]=t(C)[lower.tri(C)]
diag(C)=1
as=asg.new(C)
round(as$sigma,3)
```

```
##       A     B     C     D
## A 1.000 0.713 0.431 0.340
## B 0.713 1.000 0.655 0.511
## C 0.431 0.655 1.000 0.644
## D 0.340 0.511 0.644 1.000
```

```r
plot(as,type="corplot")
as$theta
```

```
##   A B C D
## A 0 1 0 0
## B 1 0 1 0
## C 0 1 0 1
## D 0 0 1 0
```

```r
plot(as)
```

![Visualization of correlation matrix sigma and the adjacency matrix theta](figure/corplot-1.png)

As we can see, the correlations are now slightly altered. A simply
*r* thresholding mechanism, for instance taking only correlation larger than 0.5
into consideration would as well have false positive edges like between the nodes B and D. The
function *asg.new* takes as input either a correlation matrix or a data matrix
or data.frame and tries to find such association chains. The association chain
is stored in the internal object theta and can be visualized using the default
plot command.


## Swiss dataset example


```r
library(asg)
data(swiss)
par(mfrow=c(1,2))
options(warn=-1)
as=asg.new(swiss,method="spearman")
plot(as,layout="circle",vertex.size=8)
as=asg.new(swiss,method="pearson")
plot(as,layout="circle",vertex.size=8)
```

![Swiss data associations](figure/plot-1.png)


```r
knitr::kable(as$theta)
```



|                 | Fertility| Agriculture| Examination| Education| Catholic| Infant.Mortality|
|:----------------|---------:|-----------:|-----------:|---------:|--------:|----------------:|
|Fertility        |         0|           0|           1|         1|        1|                1|
|Agriculture      |         0|           0|           1|         0|        0|                0|
|Examination      |         1|           1|           0|         1|        1|                0|
|Education        |         1|           0|           1|         0|        0|                0|
|Catholic         |         1|           0|           1|         0|        0|                0|
|Infant.Mortality |         1|           0|           0|         0|        0|                0|



```r
mtest = function (x) { return(shapiro.test(x)$p.value)  }
df=data.frame(orig=round(apply(swiss,2,mtest),3))
df=cbind(df,log2=round(apply(log2(swiss),2,mtest),3))
knitr::kable(df)
```



|                 |  orig|  log2|
|:----------------|-----:|-----:|
|Fertility        | 0.345| 0.003|
|Agriculture      | 0.193| 0.000|
|Examination      | 0.256| 0.006|
|Education        | 0.000| 0.257|
|Catholic         | 0.000| 0.000|
|Infant.Mortality | 0.498| 0.008|

## Summary

There are just three functions to be used by the normal user of the package:

* _asg.new_ - create an asg graph object
* _asg.getChains_ - to get the actual chains which are found and which build the graph
* _asg.rsquare_ - get r-square values for the nodes based on linear model to have a qualitative measure for the graph predeiction. 
* _plot.asg_ - plot an asg graph object


The asg graph object contains a few variables which might be of interest for the user:

* _alpha_ - the chosen p-value threshold
* _chains_ - the found association chains
* _data_ - the input data
* _method_ - the correction method
* _p-values_ the pairwise p-values
* _probabilities_ - in case of bootstrapping the proportion how often a chain was found
* _theta_ - the adjacency matrix for the nodes / variables

## Build information

The package was build using R version 4.1.2 (2021-11-01) on x86_64-redhat-linux-gnu using asg package 0.8.0.


```r
print(sessionInfo())
```

```
## R version 4.1.2 (2021-11-01)
## Platform: x86_64-redhat-linux-gnu (64-bit)
## Running under: Fedora Linux 35 (Workstation Edition)
## 
## Matrix products: default
## BLAS/LAPACK: /usr/lib64/libflexiblas.so.3.1
## 
## locale:
##  [1] LC_CTYPE=en_US.UTF-8       LC_NUMERIC=C              
##  [3] LC_TIME=en_US.UTF-8        LC_COLLATE=en_US.UTF-8    
##  [5] LC_MONETARY=en_US.UTF-8    LC_MESSAGES=en_US.UTF-8   
##  [7] LC_PAPER=en_US.UTF-8       LC_NAME=C                 
##  [9] LC_ADDRESS=C               LC_TELEPHONE=C            
## [11] LC_MEASUREMENT=en_US.UTF-8 LC_IDENTIFICATION=C       
## 
## attached base packages:
## [1] stats     graphics  grDevices utils     datasets  methods   base     
## 
## other attached packages:
## [1] asg_0.8.0    MASS_7.3-54  knitr_1.36.7
## 
## loaded via a namespace (and not attached):
## [1] compiler_4.1.2 magrittr_2.0.1 tools_4.1.2    rpart_4.1-15   stringi_1.7.5 
## [6] highr_0.9      stringr_1.4.0  xfun_0.27      evaluate_0.14
```

## References
