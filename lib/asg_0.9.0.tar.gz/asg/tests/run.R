library(asg)

x = 2+2

if (x != 4) {
    stop("Error: something strange happened!")
}
