#!/usr/bin/env Rscript 

library(asg)

BB1=mgraph.new(type="barabasi",m=1,nodes=20)
BB2=mgraph.new(type="barabasi",m=2,nodes=20)
W=mgraph.new(type="werner")
B=mgraph.new(type="band",nodes=10)
graphs = list(WERN=W,BAB1=BB1,BAB2=BB2,BAND=B)
df=data.frame()
for (gt in names(graphs)) {
    print(paste("proccessing",gt))
    for (i in 1:5) {
        data=t(mgraph.graph2data(graphs[[gt]],iter=100,prop=0.02))
        for (method in c("pearson","spearman")) {
            for (p in c(FALSE,TRUE)) {
                res = asg.bench(graphs[[gt]],FUN=function() { return(asg.new(data,method=method,alpha=0.1,prob=p)$theta) })
                dfn=cbind(t(data.frame(unlist(res))),method=paste("asg",method,p,sep="."),type=gt)
                
                if (nrow(df)==0) {
                    df=dfn
                } else {
                    df=rbind(df,dfn)
                }
                if (!p) {
                    res = asg.bench(graphs[[gt]],FUN=function() { return(asg.cm(asg.new(data,method=method,alpha=0.1,prob=p))$theta) })
                    dfn=cbind(t(data.frame(unlist(res))),method=paste("asg",method,p,"cm",sep="."),type=gt)
                    df=rbind(df,dfn)
                }

            }
        }
    }
}

rownames(df)=1:nrow(df)
df=as.data.frame(df)
for (i in 1:4) {
    df[,i]=as.numeric(df[,i])
}
pdf("output-benchmark.pdf",width=12,heigh=9)
bwplot(SENS~method|type,data=df)
bwplot(SPEC~method|type,data=df)
bwplot(MCC~method|type,data=df)
dev.off()

bwplot(MCC~method|type,data=df)
#print(df)
