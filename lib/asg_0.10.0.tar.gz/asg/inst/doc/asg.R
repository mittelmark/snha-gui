## ----fig.width=9,fig.height=6,fig.cap="Birth weight data variable interactions"----
par(mfrow=c(1,2),mai=c(0.8,0.8,0.1,0.2))
set.seed(125)
# retrieve some data
library(MASS)
data(birthwt)
birthwt$low=NULL # remove column
rnd=round(rnorm(nrow(birthwt),mean=10,sd=2),2)
birthwt=cbind(birthwt,rnd=rnd) # adding a random var
head(birthwt)
# analysis - spearman is safer than pearson, alpha = 0.1 is OK
# as the algorithm is robust agains spurious associations
library(asg)
pca=prcomp(t(scale(birthwt)))
asg.pcaplot(pca)
as=asg.new(birthwt,method="spearman",alpha=0.1) 
par(mai=c(0.8,0.2,0.1,0.2))
plot(as,layout="sam",vertex.size=7,lwd=3,edge.width=3)
box()

## -----------------------------------------------------------------------------
round(asg.rsquare(as),2)
as$theta

## ----label=dec,fig.width=8,fig.height=5,fig.cap="Decathlon Data 1988"---------
par(mai=c(0.2,0.2,0.7,0.1))
data(decathlon88)
head(decathlon88)
A=asg.new(decathlon88,method="spearman",alpha=0.1)
cols=rep("salmon",10)
cols[names(A$data) %in% c("jave","shot","disc","pole")]="skyblue"
plot(A,layout="sam",vertex.color=cols,vertex.size=7,cex=1.1,edge.width=5)
asg.rsquare(A)
mn=mean(asg.rsquare(A))
title(paste("R-square = ",round(mn,2)))

## ----label=start,fig.width=5,fig.height=1.5,fig.cap="An association chain"----
par(mai=c(0.1,0.1,0.1,0.0))
plot(1,xlab="",ylab="",axes=FALSE,type="n",xlim=c(0.5,4.5),ylim=c(0.8,1.2))
arrows(1:3,rep(1,3),1:3+0.8,rep(1,3),lwd=3,length=0.1)
points(1:4,rep(1,4),pch=19,col="salmon",cex=6)
text(1:4,1,LETTERS[1:4],cex=2)

## ----result='asis'------------------------------------------------------------
C=matrix(c(1,0.7,0.5,0.3,
           0.7,1,0.7,0.5,
           0.5,0.7,1,0.7,
           0.3,0.5,0.7,1),
           nrow=4,byrow=TRUE)
rownames(C)=colnames(C)=LETTERS[1:4]           
knitr::kable(C)

## ----label=corplot,fig.width=6,fig.height=3,fig.cap="Visualization of correlation matrix sigma and the adjacency matrix theta"----
set.seed(123)
par(mfrow=c(1,2),mai=c(0.1,0.1,0.1,0.1))
C=C+rnorm(length(C),mean=0,sd=0.1)
C[lower.tri(C)]=t(C)[lower.tri(C)]
diag(C)=1
as=asg.new(C)
round(as$sigma,3)
plot(as,type="corplot")
as$theta
plot(as)

## ----label=plot,fig.width=8,fig.height=4,fig.cap="Swiss data associations"----
par(mai=c(0.2,0.2,0.2,0.1))
library(asg)
data(swiss)
par(mfrow=c(1,2))
options(warn=-1)
as=asg.new(swiss,method="spearman")
plot(as,layout="circle",vertex.size=8)
as=asg.new(swiss,method="pearson")
plot(as,layout="circle",vertex.size=8)

## ----label=theta,results='asis'-----------------------------------------------
knitr::kable(as$theta)

## ----result="asis"------------------------------------------------------------
mtest = function (x) { return(shapiro.test(x)$p.value)  }
df=data.frame(orig=round(apply(swiss,2,mtest),3))
df=cbind(df,log2=round(apply(log2(swiss),2,mtest),3))
knitr::kable(df)

## ----fig=TRUE,fig.height=6,fig.height=4---------------------------------------
B = mgraph.new(type="angie",nodes=15,edges=20)
plot(B,layout="sam")

## ----fig=TRUE,fig.width=8,fig.height=5----------------------------------------
par(mar = c(5, 1, 1, 1), xpd = TRUE)
B=mgraph.new(type="barabasi",nodes=15,edges=20)
h=mgraph.harmonic_centrality(B)
h
cols=mgraph.nodeColors(B,type="harmonic")
plot(B,vertex.size=4+5*h,layout="sam",vertex.color=cols)
lg=mgraph.nodeColors(B,type="harmonic",legend=TRUE)
legend("top",fill=lg$col, inset=c(1.0,1.0),legend=lg$legend,ncol=6,)

## -----------------------------------------------------------------------------
print(sessionInfo())

