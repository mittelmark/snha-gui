#' @title asg package - association chain graphs from correlation networks
#' @description The asg package can b used to construct association chain graphs based on the St. Nicolas House algorithm as described in Groth et. 2019.
#' @details The package provides the following functions:
#' 
#' Function for graph generation from data:
#' \describe{
#' \item{\link[asg:asg.new]{asg.new(data)}}{creates and returns a new asg graph}
#' }
#'
#' S3 methods for asg graphs:
#' \describe{
#' \item{\link[asg:plot.asg]{plot.asg(asggraph)}}{plots an asg graph}
#' }
#'
#' Utility functions:
#' \describe{
#' \item{\link[asg:asg.getChains]{asg.getChains(asggraph)}}{returns the chains found by the algorithm as matrix}
#' \item{\link[asg:asg.getFactors]{asg.getFactors(data,factors=0)}}{performs a factor analysis on the given data}
#' \item{\link[asg:asg.layout]{asg.layout(g)}}{calculate layout coordinates for the given graph or adjacency matrix}
#' \item{\link[asg:asg.ll]{asg.ll(g,chain)}}{calculate log-likelihood for the given chain of the asg graph}
#' \item{\link[asg:asg.mplot]{asg.mplot(mt)}}{plots an adjacency matrix using the plotting facilities of the asg package}
#' \item{\link[asg:asg.rsquare]{asg.rsquare(data,g)}}{for given data and graph or adjacency matrix calculate linear model r-square value}
#' }
#' 
#' More internal and explorative functions. Not required for standard applications:
#' \describe{
#' \item{\link[asg:asg.getGraphAccuracy]{asg.getGraphAccuracy(true.graph,pred.graph)}}{how close is the predicted graph to the real graph}
#' \item{\link[asg:asg.rpart]{asg.rpart(data)}}{variable importance for prediction based on regression trees}
#' \item{\link[asg:asg.pcheck]{asg.pcheck(asggraph)}}{checks graph for partial correlations between not yet connected nodes which might be added as edges if significant}
#' }
#' 
#' Below is a standard analysis pipeline using the asg graph package. We use here the swiss data as example data:
#' @examples
#' data(swiss)
#' # alpha = 0.1 is recommended for smaller sample sets, default is 0.01
#' asg=asg.new(swiss,method='spearman',alpha=0.1)
#' plot(asg,layout='sam')
#' # we can as well do resamplings
#' asg=asg.new(swiss,method='spearman',alpha=0.1,prob=TRUE)
#' plot(asg,layout='sam')
#' asg$theta
#' asg$probabilities
#' @author Detlef Groth <dgroth@uni-potsdam.de>
#' @references
#' Groth, D., Scheffler, C., & Hermanussen, M. (2019). 
#' *Body height in stunted Indonesian children depends directly on parental education and not 
#' via a nutrition mediated pathway - 
#' Evidence from tracing association chains by St. Nicolas House Analysis.* 
#' Anthropologischer Anzeiger, 76 No. 5 (2019), p. 445 - 451. \url{https://doi.org/10.1127/anthranz/2019/1027}
#' @name asg-package

NULL

#' @title Create an association chain graph.
#'
#' @description This function returns graphs which are build from association chains.
#' @param data A dataframe where network nodes are the rownames and data variables are in the columns.
#' @param alpha Confidence threshold for p-value edge cutting after all chains were generated, default: 0.01.
#' @param method Method to calculate correlation/association values, can be pearson, spearman, kendall, cor.fk (requires pcaPP package), rpart or mi (mutual information) default: 'pearson'.
#' @param threshold correlation coefficient threshold which r values should be used for chain generation., default: 0.1.
#' @param pcor should edges with high partial correlations added, default: FALSE.
#' @param check.singles should isolated nodes connected with sufficent high R^2 and significance, default: FALSE.
#' @param chains.clean should shorter chains be removed if they are in longer chains, and should reverse dubplicated chains be removed, default: TRUE
#' @param prob should be probabilities computed for each edge using bootstrapping. Only in this case the parameters starting with prob are used, default: FALSE
#' @param prob.threshold threshold to set an edge, a value of 0.5 means, that the edge must be found in 50\% of all samplings, default: 0.2
#' @param prob.n number of boostrap samples to be taken, default: 25
#' @keywords network correlation
#' @return An asg graph data object with the fields theta for the adjacency matrix, sigma for the correlation matrix, chains for the association chains and data representing the input data.
#' @examples
#' data(swiss)
#' sw.g=asg.new(swiss,method='spearman')
#' sw.g$theta
#' round(sw.g$sigma,2)
#' par(mfrow=c(1,2))
#' plot(sw.g,layout='sam')
#' plot(sw.g,layout='circle')
#' plot(sw.g,layout='star',star.center='Catholic')
#' # resampling approach
#' sw.g=asg.new(swiss,method='spearman',check.singles=TRUE,prob=TRUE)
#' sw.g$theta
#' sw.g$probabilities
#' @seealso \link[asg:plot.asg]{plot.asg}
#' @export


asg.new <- function (data,alpha=0.01,method='pearson',threshold=0.01,pcor=FALSE,
                     check.singles=FALSE,chains.clean=TRUE,
                     prob=FALSE,prob.threshold=0.2,prob.n=25) {
    t1=Sys.time()
    if (prob) {
        # check for correlation matrix
        if (nrow(data)==ncol(data) &  
                length(which(colnames(cor(data))==rownames(cor(data)))) == nrow(data)) {
                    stop("only data matrices, not correlation matrices, can be used for bootstrapping graphs")
        }

        as=asg.new(data,alpha=alpha,method=method,threshold=threshold,pcor=pcor,
                   check.singles=check.singles,prob=FALSE)
        rand.prob=as$theta
        rand.prob[]=0
        for (i in 1:prob.n) {
            sam=sample(1:nrow(data),nrow(data),replace=TRUE)
            asi=asg.new(data[sam,],alpha=alpha,method=method,threshold=threshold,pcor=pcor,
                        check.singles=check.singles,prob=FALSE,chains.clean=chains.clean)
            if (i == 1) {
                as$probabilities=asi$theta
            } else {
                as$probabilities=as$probabilities+asi$theta
                #recover()
            }
            rand.data=data
            for (i in 1:ncol(data)) {
                rand.data[,i]=sample(data[,i])
            }
            asr=asg.new(rand.data,alpha=alpha,method=method,threshold=threshold,pcor=pcor,
                        check.singles=check.singles,prob=FALSE,chains.clean=chains.clean)
            rand.prob=rand.prob+asr$theta
        }
        as$probabilities=as$probabilities/prob.n
        rand.prob=as.vector(rand.prob)/prob.n
        as$rand.probabilities=as$probabilities
        as$rand.probabilities[]=rand.prob
        as$theta[as$probabilities>=prob.threshold]=1
        as$theta[as$probabilities<prob.threshold]=0
        as$p.values=as$theta
        vprob=as.vector(as$probabilities)
        as$p.values[]=unlist(lapply(vprob,function (x) 1-length(which(x>rand.prob))/length(rand.prob)))
    } else {
        as=asgp$data2chainGraph(data,alpha=alpha,method=method,threshold=threshold)
        if (pcor) {
            for (i in 1:3) {
                as$theta=asg.pcheck(as)
            }
        }
        if (check.singles) {
            cmt=cor(data,method=method,use='pairwise.complete.obs')
            if (method!= "kendall") {
                cmt=cmt^2
            } else {
                cmt=abs(cmt)
            }
            diag(cmt)=0
            idx=which(apply(as$theta,1,sum)==0) 
            for (i in idx) {
                if (max(cmt[i,])>threshold) {
                    j=which(max(cmt[i,])==cmt[i,])
                    options(warn=-1)
                    if (cor.test(data[,i],data[,j])$p.value<alpha) {
                        as$theta[i,j]=1
                        as$theta[j,i]=1
                    }
                    options(warn=0)
                }
            }
        }
        as$probabilities=as$theta
    }
    if (chains.clean) {
        as=ReduceChains(as)
    } 
    return(as)
}
ReduceChains = function (g) {
    ichains=c()
    chs=sort(names(g$chains))
    for (cho in chs) {
        if (length(g$chains[[cho]]) == 1) {
            next
        }
        co=g$chains[[cho]]
        for (chi in chs) {
            if (length(g$chains[[chi]])==1) {
                next
                
            }
            if (length(g$chains[[cho]]) == 1) {
                next
            }

            if (chi == cho) { next }
            ci=g$chains[[chi]]
            if (length(co)> length(ci)) { next }
            if (length(co) == length(ci)) {
                if (all(co==ci) | all(co==rev(ci))) {
                    ichains=c(ichains,chi)
                    g$chains[[chi]] = ''
                }
            } else {
                cop=paste(co,collapse='')
                cipo=paste(ci,collapse='')
                cipr=paste(rev(ci),collapse='')
                if (grepl(cop,cipo,fixed=TRUE)) {
                    ichains=c(ichains,cho)
                    g$chains[[cho]] = ''

                } else if (grepl(cop,cipr,fixed=TRUE)) {
                    ichains=c(ichains,cho)
                    g$chains[[cho]] = ''
                }
            }
            
        }
    }
    for (ch in ichains) {
        g$chains[[ch]]=NULL
    }
    return(g)
}


#' @title Measure similarity between two graphs based on edges
#'
#' @description This function returns similarity measures between two graphs based on predictions of edges. 
#' The accuracy is the proportion of correctly predicted edges from all predicted edges. Also other measures, sensitivity, specificity, balanced classification rates and F1 score are releated to the predicted edges.
#' 
#' @param true.graph an qadjacency matrix or an asg graph object
#' @param pred.graph an adjacency matrix or an asg graph object
#' @return A list object with measures such as accuracy, sensitivity, specificity, balanced classification rate and F-score.
#' @examples
#' data(swiss)
#' sw.g=asg.new(swiss)
#' G=sw.g$theta # assume that this is the true graph
#' G
#' H=sw.g$sigma^2 # create a simple threshold based graph
#' H[H>0.1]=1
#' H[H<=0.1]=0
#' diag(H)=0
#' H
#' asg.getGraphAccuracy(G,H)
#' @name asg.getGraphAccuracy
#' @export

asg.getGraphAccuracy = function (true.graph,pred.graph) {
    if (class(pred.graph)[1]=="asg") {
        MP=pred.graph$theta
    } else {
        MP=pred.graph
    }
    if (class(true.graph)[1]=="asg") {
        MT=true.graph$theta
    } else {
        MT=as.matrix(true.graph)
    }

    TP=length(which(MT[upper.tri(MT)]+MP[upper.tri(MP)] == 2  ))
    TN=length(which(MT[upper.tri(MT)]+MP[upper.tri(MP)] == 0  ))
    FN=length(which(MT[upper.tri(MT)]-MP[upper.tri(MP)] == 1  ))
    FP=length(which(MT[upper.tri(MT)]-MP[upper.tri(MP)] == -1 ))
    N=TN+FN
    P=TP+FP
    Sens=TPR=TP/(TP+FN)
    Spec=TN/(FP+TN)
    Acc=(TP+TN)/(N+P)
    #BCR=(TP/P + TN/N)/2
    BCR=(Sens+Spec)/2
    MCC=(TP*TN - FP*FN)/sqrt(1.0*(TP+FP)*(TP+FN)*(TN+FP)*(TN+FN))
    FScore=2*TP/(2*TP+FP+FN)
    return(list(Sens=Sens,Spec=Spec,Acc=Acc,BCR=BCR,MCC=MCC,F1=FScore))
}
#' @title Check graph for partial correlations.
#'
#' @description This is a utiltiy function to check existing edges in an asg graph object for 
#' significant partial correlations.
#' 
#' @param graph an asg graph object
#' @return a adjacency matrix where edges are checked for partial correlations.
#' @examples
#' data(swiss)
#' sw.g=asg.new(swiss)
#' M=asg.pcheck(sw.g)
#' @export

asg.pcheck = function (graph) {
    # todo check if cor.matrix
    # assume data matrix
    A=graph$theta
    S=graph$sigma
    N=A
    data=graph$data
    # for every node with degree of 2 or greater
    idx=names(which(apply(A,1,sum)>1) )
    for (node in sample(idx)) {
        nghs=names(which(A[node,]>0))
        for (n in 1:(length(nghs)-1)) {
            for (m in n:length(nghs)) {
                if (n != m) {
                    if (A[nghs[m],nghs[n]]==0) {
                        # add significant partial correlations
                        pc=asg.pcor.test(data[,nghs[n]],data[,nghs[m]],data[,node])
                        if(pc$p.value<0.01 && pc$estimate>0.2) {
                            N[nghs[m],nghs[n]]=1
                            N[nghs[n],nghs[m]]=1
                        } 
                        # remove non significant partial correlations
                        pc=asg.pcor.test(data[,node],data[,nghs[m]],data[,nghs[n]])
                        if(pc$p.value>0.1) {
                            N[nghs[m],node]=0
                            N[node,nghs[m]]=0
                        }
                        pc=asg.pcor.test(data[,node],data[,nghs[n]],data[,nghs[m]])
                        if(pc$p.value>0.1) {
                            N[nghs[n],node]=0
                            N[node,nghs[n]]=0
                        }
                    }
                }
            }
        }
    }
    return(N)
    # for every pair of neighbor nodes
    # check partial correlation 
}
#' @title Return the chains of an asg graph as data frame
#'
#' @description This is a utiltiy function to return the chains which constructs the graph as a matrix.
#' 
#' @param graph an asg graph object
#' @return A matrix with one chain per row. Shorter chains are filled up with empty strings.
#' @examples
#' data(swiss)
#' sw.g=asg.new(swiss)
#' asg.getChains(sw.g)
#' @export

asg.getChains = function (graph) {
    mx=max(as.numeric(lapply(graph$chains,length)))
    l=length(as.numeric(lapply(graph$chains,length)))
    mt=matrix("",nrow=l,ncol=mx+1)
    colnames(mt)=c("Name",paste("Node",1:mx,sep=""))
    for (n in 1:length(names(graph$chains))) {
        name=names(graph$chains)[n]
        mt[n,1]=name
        for (m in 1:length(graph$chains[[name]])) {
            mt[n,m+1]=graph$chains[[name]][m]
        }
    }
    return(mt)
}
#' @title Performs a simple factor analysis and performs the Factor ids.
#'
#' @description This function returns a list with two elements the factor analysis ids for each variable and a factor analysis object of class factanal.
#' 
#' @param x A formula or a numeric matrix or an object that can be coerced to a numeric matrix.
#' @param factors The number of factor to be fitted. If 0 is given the function will select the number of factors which explain more than 90\% of the variablity of the data set or the the maximum possible number of factors.
#' @param na.omit What do with missing values, if TRUE all rows and columns with missing values will be deleted, if FALSE an error is thrown, default: FALSE
#' @param \dots Arguments delegated to the factanal function.
#' @return A list object with factor ids, proportional variance and the factanal object.
#' @examples
#' data(swiss)
#' fact=asg.getFactors(swiss)
#' fact$ids
#' fact$var
#' plot(asg.new(swiss),hilight.factors=TRUE,factors=2)
#' @importFrom stats factanal
#' @export

asg.getFactors = function (x,factors=0,na.omit=TRUE,...) {
    f=factors
    nx=na.omit(x)
    if (!all(dim(nx)==dim(x))) {
        if (!na.omit) {
            stop("Data contain NA's, either impute data or use na.omit=TRUE to calculate factors without NA's")
        } else {
            x=nx
            warning("Values missing, all rows and columns with missing values were deleted!")
        }
    }
    if (f==0) {
        for (i in 2:10) {
            f=i
            fact=factanal(x,f,...)
            sums=colSums(fact$loading*fact$loading)/dim(fact$loading)[1]
            cs=cumsum(sums)[1]
            cumvar=cs[[length(cs)]]

            if (fact$dof==0) {
                break
            }

            if (cumvar>0.9) {
                break
            }
        }
    }

    fact=factanal(x,f,...)
    sums=colSums(fact$loading*fact$loading)/dim(fact$loading)[1]
    cs=cumsum(sums)[1]

    res=t(apply(fact$loadings[,],1,function(x) { return(which(x==max(x))) }))
    return(list(ids=res[1,],var=sums,fact=fact))
}


# private functions to implement the functionality
asgp=new.env()

asgp$getChains = function (cor.mt, square=TRUE,top=10, 
                           threshold=0.01, maxl=3) {
  
  getMiddleChain = function (forchain,mt2) {
    res=c()
    for (fi in 2:(length(forchain)-1)) {
      fl=forchain[fi]
      found=FALSE
      for (si in (fi+1):length(forchain)) {
        sl=forchain[si]
        mt2=mt2[order(mt2[,sl],decreasing = TRUE),]
        schain=rev(rownames(mt2))
        mt2=mt2[order(mt2[,fl],decreasing = TRUE),]                    
        fchain=rownames(mt2)
        if (identical(fchain,schain)) {
          # collect results
          res=fchain        
          found = TRUE
          break
        }
      }
      if (found) { break }
    }
    return(res)
  }
  # remove non-correlated values
  #cor.mt[abs(cor.mt)<0.05]=0
  cor.mt=abs(cor.mt)
  if (square) {
    cor.mt=cor.mt^2
  } else {
    threshold=0.1
  }
  if (top>nrow(cor.mt)) {
    top=nrow(cor.mt)
  }
  results=list()
  chained=list()
  for (i in 1:ncol(cor.mt)) {
    # for each node create a r-ordered list of nodes
    node=colnames(cor.mt)[i]
    mt=cor.mt[order(cor.mt[,i],decreasing = TRUE),][1:top,]
    # ignore nodes without any correlation to any other node
    # might be ignored
    # initial full chain
    chain=rownames(mt)
    cor.mt2=cor.mt[chain,chain]
    j = length(chain)
    lchain=chain[j]
    mt=cor.mt2[order(cor.mt2[,lchain],decreasing = TRUE),]
    # reverse chain
    revchain=rev(rownames(mt))
    forchain=chain
    # as long reversed revchain and chain are different
    # shorten  until the same chain ist found in both
    # or it is to short
    # direct chains
    l=length(forchain)
    while (l>maxl) {
      l=l-1
      lchain=chain[l]
      forchain=forchain[1:l]
      mt2=cor.mt2[forchain,forchain]
      mt2=mt2[order(mt2[,lchain],decreasing = TRUE),]
      if (abs(mt2[nrow(mt2),lchain])<threshold) {
        next
      }
      # revchain is shorter automatically
      # as we have reduced mt2
      revchain=rev(rownames(mt2))
      if (identical(revchain,forchain)) {
        # collect results
        key=paste("a-chain-",node,sep="")
        results[[key]]=forchain        
        break
      }
      # otherwise
      # new: try all chains with node inside, not only 
      # in the beginning as above
      res=getMiddleChain(forchain,mt2)
      if (length(res) > 0) {
        key=paste("m-chain-",node,sep="")
        results[[key]]=res
        break ;# todo remove break??
        }
    }
  }
  return(results);
}

asgp$chains2edgelists = function (chainlist) {
    self=asgp
    edgelists=c()
    for (name in names(chainlist)) {
        for (i in seq(1,length(chainlist[[name]])-1,by=1)) {
            edgelists=c(edgelists,paste(chainlist[[name]][i],chainlist[[name]][i+1],sep="--"))
        }
    }
    return(edgelists)
}

asgp$data2chainGraph = function (data,method='pearson',
                                square=TRUE,
                                threshold=0.01,maxl=3,top=10,
                                p.adjust='none',
                                alpha=0.01,
                                cor.p.value=NULL) {
    self=asgp
    if (nrow(data)==ncol(data) &&  
        length(which(colnames(cor(data))==rownames(cor(data)))) == nrow(data)) {
        if (max(data)>1) {
            stop("symmetric matrices must be correlation matrices")
        }
        cormt=data
        if (length(cor.p.value)==0) {
            # pseudo p-values
            # will add 1's later
            cor.p.value=matrix(0,nrow=nrow(data),ncol=nrow(data))
        }
        
    } else {
        if (method == "mi") {
            mi=asg.mutualInfo(data)
            mi=mi/max(mi)
            cormt=mi
            cor.p.value=matrix(0,nrow=nrow(data),ncol=nrow(data))
            square=FALSE;threshold=0.001
        } else if (method == "rpart") {
            rp=asg.rpart(data,correct=TRUE)
            rp=rp/apply(rp,1,sum)
            for (i in 1:(ncol(rp)-1)) {
                for (j in i:ncol(rp)) {
                    rp[j,i]=rp[i,j]=max(c(rp[j,i],rp[i,j]))
                }
            }

            cormt=rp
            cor.p.value=matrix(0,nrow=nrow(data),ncol=nrow(data))
            square=FALSE;threshold=0.1
        } else if (method == "cor.fk") {
            if (!require("pcaPP")) {
                stop("Error: method cor.fk requires package pcaPP, please install it!")
            }
            cormt=matrix(1,nrow=ncol(data),ncol=ncol(data))
            rownames(cormt)=colnames(cormt)=colnames(data)
            for (i in 1:(ncol(data)-1)) {
                for (j in (i+1):ncol(data)) {
                    idx=which(!is.na(data[,i]) & !is.na(data[,j]))
                    cormt[i,j]=cormt[j,i]=cor.fk(data[idx,i],data[idx,j])
                }
            }
            cor.p.value=cormt
            cor.p.value[]=0
            cor.p.value[abs(cormt<0.01)]=1
        } else {
            options(warn=-1)
            cormt=cor(data,method=method,use='pairwise.complete.obs')
            if (method == "kendall") {
                square=TRUE
                cormt=cormt
            }
            options(warn=0)
            #cormt[is.na(cormt)]=0
            cor.p.value=self$corTest(data,method=method,p.adjust=p.adjust)$p.value 

        }
    }
    #print(threshold)
    # if all pairs are NA
    cor.p.value[is.na(cormt)]=1
    cormt[is.na(cormt)]=0
    chains=self$getChains(cormt,square=square,threshold=threshold,
                          maxl=maxl,top=top)
    edgelist=self$chains2edgelists(chains)
    A=matrix(0,nrow=ncol(data),ncol=ncol(data))
    colnames(A)=rownames(A)=colnames(data)
    for (edge in edgelist) {
        # print(edge)
        nodes=strsplit(edge,"--")[[1]]
        A[nodes[1],nodes[2]]=A[nodes[2],nodes[1]]=1
    }
    if (max(cor.p.value)==0) {
        # cor matrix was given
        # set all non edges to not significant
        # as we can't calculate p-values
        cor.p.value[A==0]=1
    }
    if (alpha < 1) {
        # remove non signif edges
        A=self$removeNonsignifGraphEdges(A,cor.p.value,alpha=alpha)
    }
    asgm=list(theta=A,p.values=cor.p.value,data=data,sigma=cormt,
              method=method,threshold=threshold,alpha=alpha,chains=chains,data=data)
    class(asgm)="asg"
    return(asgm)
}

asgp$corTest = function (data,method='pearson',p.adjust='none') {
    self=asgp
    options(warn=-1)
        
    cor.p.values <- function(r, n) {
        df <- n - 2
        STATISTIC <- c(sqrt(df) * r / sqrt(1 - r^2))
        p <- pt(STATISTIC, df)
        return(2 * pmin(p, 1 - p))
    }
    
    
    pmatrix = function (M,method="pearson") {
        P=matrix(0,ncol=ncol(M),nrow=ncol(M))
        
        rownames(P)=colnames(P)=colnames(M)
        if (method=="spearman") {
            M=apply(M,2, rank,na.last="keep")
        }
        r=cor(M,use="pairwise.complete.obs")
        ncd=ncol(M)
        #N=unlist(sapply(1:(ncd-1), function(i) sapply((i+1):ncd, function(j) nrow(na.omit(M[,c(i,j)])))) )
        #print(length(N))
        N=c()
        for (i in 1:(ncd-1)) {
            for (j in (i+1):ncd) {
                N=c(N,nrow(na.omit(M[,c(i,j)])))
            }
        }
        P[upper.tri(P)]=apply(cbind(r=r[upper.tri(r)],N=N),1, function (x) cor.p.values(x[1],x[2]))
        P[lower.tri(P)]=t(P)[lower.tri(P)]
        return(list(r=r,P=P))
    }

    if (method=="pearson" | method == "spearman") {
        res=pmatrix(data,method=method)
        cor.mt=res$r
        p.value=res$P
        diag(p.value)=0
        diag(cor.mt)=1
    } else {
        cor.mt=cor(data,method=method,use='pairwise.complete.obs')
        p.value=matrix(0,nrow=ncol(data),ncol=ncol(data))
        ncd=ncol(data)
        # this is not faster anymore with modern R versions
        #N=sapply(1:(ncd-1), function(i) sapply((i+1):ncd, function(j) nrow(omit.na(data[,c(i,j)])))) 
        #                                     function(j) {
        #                                         p.value[i,j]=p.value[j,i]=cor.test(data[,i],data[,j],method=method)$p.value
        #                                     }))
        for (i in 1:(ncd-1)) {
            for (j in (i+1):ncd) {
                p.value[i,j]=p.value[j,i]=cor.test(data[,i],data[,j],method=method,exact=FALSE)$p.value
            }
        }
    }
    options(warn=0)
    rownames(p.value)=colnames(p.value)=colnames(data)
    if (p.adjust != "none") {
        #print("correcting")
        p.adj=p.adjust(p.value[upper.tri(p.value)],method=p.adjust)
        p.value[upper.tri(p.value)]=p.adj
        p.value[lower.tri(p.value)]=t(p.value)[lower.tri(p.value)]
        
    }
    
    return(list(r=cor.mt,p.value=p.value,p.adjust=p.adjust))
}

asgp$removeNonsignifGraphEdges = function (A,p.value,alpha=0.05,...) {
    self=asgp
    if (sum(A)==0) {
        return(A)
    }
    #print(p.value)
    dels=c()
    for (i in 1:(ncol(A)-1)) {
        for (j in i:(ncol(A))) {
            if (p.value[i,j] > alpha) {
                A[i,j]=A[j,i]=0
            }
        } 
    }
    return(A)
}
asgp$new = function (data) {
    self=asgp
    # to A
    # save layouts MDS, circle
    # methods plots
    #return(list(A,mds.layout))
}

# methods for asg graph

#' @title `plot.asg` display of network and correlation matrices of asg graphs.
#' @description `plot.asg` provides a simple display of network graphs correlation matrices using 
#' filled circles (vertices) to represent variables and edges which connect the vertices with high absolute
#' correlation values.
#' @details This is a small plot utility to display networks or correlation matrices of asg graph objects.
#' @param x asg graph object usually results of asg.new
#' @param type character string specifying the plot type either 'network' or 'cor', default: 'network'.
#' @param layout graph layout for plotting one of 'circle', 'sam', 'samd', 'grid', 'mds', 'mdsd', 'star', default: 'circle'.
#' @param vertex.color default color for the vertices, default: 'salmon'.
#' @param cex size of the vertex labels which are plotted on the vertices, default: 1.
#' @param vertex.size Number how large the vertices should be plotted, default: 5.
#' @param edge.width Number on how strong the edges should be plotted, if edge.width=0, then the number is based on the correlation values, default: 2.
#' @param edge.color Color to be plotted for edges. Usually vector of length two. First color for positive correlations, second color for negative corrleations. Default: c('grey','red').
#' @param noise Should be noise added to the layout. Sometimes useful if nodes are too close. Default: FALSE
#' @param hilight.factors Should factors from a factor analysis be hilighted. Default: FALSE
#' @param hilight.chain which chain should be highlighted, default: NULL (no chain highlight)
#' @param chain.color which color for chain edges, default: black
#' @param factors The number of factor to be fitted. If 0 is given the function will select the number of factors which explain more than 90\% of the variablity of the data set or the the maximum possible number of factors. Please note, that some of the matrices might be not suitable for factor analysis. Default: 0
#' @param star.center the centered node if layout is start, must be a character string for the nodename, default: NULL
#' @param plot.labels should node labels plotted, default: TRUE
#' @param lty line type for standard edges in the graph, default: 1
#' @param threshold cutoff values for bootstrap probabilities for drawing edges as dotted. broken lines and solid lines, default: c(0.25,0.5,0.75)
#' @param interactive switch into interactive mode where you can click in the graph and move nodes with two clicks, first selecting the node, second click gives thehe new coordinates for the node, default: FALSE
#' @param \dots curently not used 
#' @return returns the layout of the plotted network or NULL if type is corplot (invisible) .
#' @import graphics stats
#' @examples 
#' data(swiss)
#' sw.g=asg.new(swiss,method='spearman')
#' sw.g$theta
#' round(sw.g$sigma,2)
#' plot(sw.g,type='network',layout='circle')
#' plot(sw.g,type='network',layout='sam')
#' plot(sw.g,type='corplot')
#' # vertex width based in correlations, colors based on factor groups
#' plot(sw.g,hilight.factors=TRUE,layout='sam',vertex.size=15,edge.width=0)
#' sw.g=asg.new(swiss,method='spearman',prob=TRUE)
#' sw.g$theta
#' sw.g$probabilities
#' plot(sw.g,type='network',layout='sam')
#' sw.g$chains
#' # plot chains for a node
#' plot(sw.g,layout="sam",lty=2,hilight.chain="Infant.Mortality",
#'  edge.width=3,edge.color=c("black","red"))
#' @name plot.asg
#' @export

plot.asg = function (x,type='network',
                     layout='circle',
                     vertex.color='salmon',cex=1,
                     vertex.size=5,edge.width=2,
                     edge.color=c('grey','red'),noise=FALSE, 
                     hilight.factors=FALSE,factors=0,
                     hilight.chain=NULL,
                     chain.color=c('black','red'),
                     star.center=NULL,
                     plot.labels=TRUE,
                     lty=1,threshold=c(0.25,0.5,0.75),
                     interactive=FALSE,...) {
    g=x
    if (any(class(g) %in% "matrix")) {
        g=as.data.frame(g)
    }
    getPCols = function (n) {
        if(n > 20 |  n < 1) {
            stop("only between 1 and 20 colors can be given" ) 
        }
        pcols= c("#FFC5D0","#FDC8C3","#F6CBB7","#EDD0AE","#E2D4A8","#D4D8A7","#C5DCAB","#B6DFB4","#A8E1BF",
                 "#9EE2CB", "#99E2D8","#9BE0E5","#A4DDEF","#B3D9F7","#C4D5FB","#D5D0FC","#E4CBF9","#F0C7F2",
                 "#F9C5E9", "#FEC4DD")
                 idx=seq(1,20,by=floor(20/n))
                 return(pcols[idx])
    }

    if (type %in% c('corrplot','cor','corplot')) {
        asg.corrplot(g$sigma,text.lower=TRUE,...)
        lay=NULL
    } else {
        if (any(class(layout) %in% "character")) {
            if (class(g)[1]=="asg") {
                xy=asg.layout(g,mode=layout,noise=noise,star.center=star.center,method=g$method)    
            } else {
                xy=asg.layout(g,mode=layout,noise=noise,star.center=star.center)    
            }
        } else if (any(class(layout) %in% 'matrix')) {
            xy=layout
        }
        doPlot = function (theta,sigma,xy,node=NULL,probabilities=NULL,cmatrix=NULL,...) {
            xrange=range(xy[,1])
            yrange=range(xy[,2])
            xlim=c(xrange[1]-1/10*diff(xrange),xrange[2]+1/10*diff(xrange))
            ylim=c(yrange[1]-1/10*diff(yrange),yrange[2]+1/10*diff(yrange))
            if (class(probabilities)[1] == "NULL") {
                probabilities=theta
            }
            plot(xy,pch=19,col="salmon",cex=vertex.size,axes=FALSE,xlab="",ylab="",
                 xlim=xlim,ylim=ylim,...)
            
            for (i in 1:(nrow(theta)-1)) {
                for (j in i:nrow(theta)) {
                    if (theta[i,j]==1 | theta[i,j] == -1) {
                        x1=xy[rownames(theta)[i],1]
                        x2=xy[rownames(theta)[j],1]
                        y1=xy[rownames(theta)[i],2]
                        y2=xy[rownames(theta)[j],2]
                        if (edge.width==0) {
                            ew=as.numeric(cut(abs(sigma[i,j]),breaks=c(0,0.1,0.3,0.5,1)))
                        } else {
                            ew=edge.width
                        }
                        if (abs(probabilities[i,j])>threshold[3]) {
                            lty=1
                        } else if (abs(probabilities[i,j])>threshold[2]) {
                            lty=2
                        } else if (abs(probabilities[i,j])>threshold[1]) {
                            lty=3
                        } else {
                            lty=0
                        }
                        if (sigma[i,j]>0) {

                            if (!is.null(hilight.chain) && cmatrix[i,j] > 0) {
                                lines(c(x1,x2),c(y1,y2),lwd=ew,col=chain.color[1],lty=1)
                            } else {
                                lines(c(x1,x2),c(y1,y2),lwd=ew,col=edge.color[1],lty=lty)
                            }
                        } else {
                            if (!is.null(hilight.chain) && cmatrix[i,j] > 0) {
                                lines(c(x1,x2),c(y1,y2),lwd=ew,col=chain.color[2],lty=1)
                            } else {

                                lines(c(x1,x2),c(y1,y2),lwd=ew,col=edge.color[2],lty=lty)
                            }
                        }
                    }
                }
            }
            points(xy,pch=19,col="black",cex=vertex.size+0.3)
            if (class(g)[1] == "asg" && hilight.factors) {
                ids=asg.getFactors(g$data,factors=factors)$ids
                maxid=max(ids)
                cols=getPCols(maxid)[ids]
                points(xy,pch=19,col=cols,cex=vertex.size)
            } else {
                points(xy,pch=19,col=vertex.color,cex=vertex.size)
            }
            if (plot.labels) {
                text(xy,rownames(theta),cex=cex)
            }
            return(xy)
        }
        lay=xy
        if (class(g)[1] =="asg") {
            if (class(hilight.chain)[1] != "NULL") {
                cmatrix=g$sigma
                cmatrix[]=0
                chns=grep(hilight.chain,names(g$chains))
                for (nm in names(g$chain)[chns]) {
                    for (i in 1:(length(g$chain[[nm]])-1)) {
                        x=g$chain[[nm]][i]
                        y=g$chain[[nm]][i+1]
                        cmatrix[x,y]=1
                        cmatrix[y,x]=1
                    }
                }
                #print(cmatrix)
            }
            if (interactive) {
                print("click two times, first on the point to move, second where to move\nEnd with one or two right clicks!")
                while (TRUE) {
                    loc=locator(2)
                    if (class(loc) == "NULL" | class(loc$x[2]) == "NULL" | class(loc$x[1]) == "NULL") {
                        break
                    }
                    dlay=rbind(lay,c(loc$x[1],loc$y[1]))
                    d=as.matrix(dist(dlay))[nrow(dlay),1:(nrow(dlay)-1)]
                    nm=names(which(d==min(d)))[1]
                    lay[nm,1]=loc$x[2]
                    lay[nm,2]=loc$y[2]
                    lay=doPlot(g$theta,g$sigma,lay,probabilities=g$probabilities,cmatrix=cmatrix,...)
                }
            }
            doPlot(g$theta,g$sigma,lay,probabilities=g$probabilities,cmatrix=cmatrix,...)
        } else {
            if (interactive) {
                print("click two times, first on the point to move, second where to move\nEnd with one or two right clicks!")
                while (TRUE) {
                    loc=locator(2)
                    if (class(loc) == "NULL" | class(loc$x[2]) == "NULL" | class(loc$x[1]) == "NULL") {
                        break
                    }
                    dlay=rbind(lay,c(loc$x[1],loc$y[1]))
                    d=as.matrix(dist(dlay))[nrow(dlay),1:(nrow(dlay)-1)]
                    nm=names(which(d==min(d)))[1]
                    lay[nm,1]=loc$x[2]
                    lay[nm,2]=loc$y[2]
                    lay=doPlot(g,g,xy,probabilities=g,...)
                }
            }
                    
            # just an adjacency matrix
            doPlot(g,g,lay,probabilities=g,...)
        }
    }
    invisible(lay)
}

#' @title `asg.mplot` using the asg plot for simple adjacency matrices
#' @description `asg.mplot` provides the plot.asg functions as well for simple adjacency matrices
#' @section Details:
#' This is a small plot utility to display networks or correlation matrices of asg graph objects.
#' @param M an adjacency matrix, or an asg graph object
#' @param main title of the plot, Default: empty string
#' @param \dots all other parameters delegated to plot.asg
#' @return nothing.
#' @examples 
#' M=matrix(rbinom(100,1, 0.2),nrow=10,ncol=10)
#' diag(M)=0
#' colnames(M)=rownames(M)=LETTERS[1:10]
#' asg.mplot(M)
#' @seealso \link[asg:plot.asg]{plot.asg}
#' @export

asg.mplot = function (M,main='',...) {
    plot.asg(M,...)
    if(main!= '') {
        title(main)
    }
}
#' @title improved score plot for pca objects
#' 
#' @description The function `asg.pcaplot` provides an improved xyplot for
#'   visualizing the 2D scores of individual principal components of 
#'   an object created using the function _prcomp_. 
#' 
#' @param pca  pca object of class _prcomp_, created using the function _prcomp_.
#' @param pcs  the components to plot, default: c('PC1','PC2')
#' @param pch  plotting character, default: 19
#' @param cex  character expansion, default: 7
#' @param col  plotting color, default: salmon
#' @param text should text of samples be displayed, default: TRUE
#' @param xlab custom xlab, if not given the PC name with variance in percent is shown, default: NULL
#' @param ylab custom ylab, if not given the PC name with variance in percent is shown, default: NULL
#' @param grid   should a plot grid be drawn, default: TRUE
#' @param scale  function to scale to coordinate values sich as asinh, default: NULL
#' @param \ldots additional arguments delegated to the standard plot function
#' 
#' @examples
#' set.seed(125)
#' library(MASS)
#' data(birthwt)
#' birthwt$low=NULL # remove column
#' rnd=round(rnorm(nrow(birthwt),mean=10,sd=2),2)
#' birthwt=cbind(birthwt,rnd=rnd) # adding a random var
#' head(birthwt)
#' pca=prcomp(t(scale(birthwt)))
#' par(mfrow=c(1,2),mai=c(0.8,0.8,0.4,0.2))
#' asg.pcaplot(pca,cex=7)
#' asg.pcaplot(pca,col=rainbow(ncol(birthwt)),cex=1,text=FALSE)
#' @seealso \link[asg:plot.asg]{plot.asg}
#' @export

asg.pcaplot = function (pca,pcs=c("PC1","PC2"),
                        pch=19, cex=7,col="salmon",
                        text=TRUE,xlab=NULL,ylab=NULL,
                        grid=TRUE,scale=NULL,...) {
    if (missing("xlab")) {
        xlab=paste(pcs[1]," (", round(summary(pca)$importance[2,pcs[1]]*100,1),"%)",sep="")
    }
    if (missing("ylab")) {
        ylab=paste(pcs[2]," (", round(summary(pca)$importance[2,pcs[2]]*100,1),"%)",sep="")
    }   
    if (class(scale)=="function") {
        x=scale(pca$x[,pcs[1]])
        y=scale(pca$x[,pcs[2]])
        xlab=paste(substitute(scale),xlab)
        ylab=paste(substitute(scale),ylab)        
        #plot(x,y,pch=pch,col=col,type="n",xlab=xlab,ylab=ylab,...)
    }
    x=pca$x[,pcs[1]]
    y=pca$x[,pcs[2]]
    xdiff=(max(x)-min(x))*0.1
    ydiff=(max(y)-min(y))*0.1
    plot(x,y,type="n",xlab=xlab,ylab=ylab,
        xlim=c(min(x)-xdiff,max(x)+xdiff),
        ylim=c(min(y)-ydiff,max(x)+ydiff),...)
    if (grid) {
        grid (NULL,NULL, lty = 3, col = "grey30")
    }
    abline(h=0,lty=2)
    abline(v=0,lty=2)    
    if (text) {
        points(x,y,pch=pch,col='black',cex=cex+0.6,...)    
    }
    points(x,y,pch=pch,col=col,xlab=xlab,ylab=ylab,cex=cex,...)
    if (text) {
        text(pca$x,rownames(pca$x))
    }
}

#' @title linear model r-square for given data and graph
#' 
#' @description `asg.rsquare` calculates for given data and a graph the covered r-squared by 
#' a linear model for each node. The linear model predicts each node by an additive mode 
#' using it's neighbor nodes in the graph.
#' 
#' @param data asg graph object or data matrix or data frame where variables are in columns and samples in rows
#' @param g graph object or adjacency matrix of an (un)directed graph, not needed if data is an asg graph, default: NULL.
#' @return vector of rsquare values for each node of the graph.
#' @examples 
#' # random data
#' A=matrix(rbinom(100,1, 0.2),nrow=10,ncol=10)
#' diag(A)=0
#' colnames(A)=rownames(A)=LETTERS[1:10]
#' data=matrix(rnorm(1000),ncol=10)
#' colnames(data)=colnames(A)
#' asg.rsquare(data,A)
#' # real data
#' data(swiss)
#' sw.s=asg.new(swiss,method='spearman')
#' rsqs=asg.rsquare(sw.s)
#' plot(sw.s,main=paste("r =",round(mean(rsqs,2))),
#'    layout='star',star.center='Examination')
#' # some colors for r-square values
#' vcols=paste("grey",seq(80,40,by=-10),sep="")
#' scols=as.character(cut(asg.rsquare(swiss,sw.s$theta),
#'    breaks=c(0,0.1,0.3,0.5,0.7,1),labels=vcols))
#' plot(sw.s,main=paste("r =",round(mean(asg.rsquare(swiss,sw.s$theta)),2)),
#'    vertex.color=scols ,layout='star',star.center='Examination',
#'    vertex.size=10,edge.color=c('black','red'),edge.width=3)
#' @export

asg.rsquare = function (data,g=NULL) {
    if (any(class(data) %in% "matrix")) {
        data=as.data.frame(data)
    }
    if (class(data)[1]=="asg") {
        g=data$theta
        data=data$data
    }
    if (class(g)[1]=="asg") {
        A=g$theta
    } else {
        A=g
    }
    if (class(g)[1] == "NULL") {
        stop("Error: An adjacency matrix g was not given to asg.rsquare!")
    }
    res=c()
    colnames(A)=rownames(A)=gsub("^([0-9])","XYZ\\1",colnames(A))
    colnames(data)=gsub("^([0-9])","XYZ\\1",colnames(data))
    rn=rownames(A)
    for (i in 1:nrow(A)) {
        nms=names(which(A[i,]==1))
        if (length(nms) == 0) {
            res=c(res,0)
            next
        }
         frmla = reformulate(termlabels = nms,  response = rn[i])
         modelLm = lm(frmla, data = data)
         rsquared = summary(modelLm)$r.squared
         res=c(res,rsquared)
     }
     names(res)=rn
     names(res)=gsub("^XYZ([0-9])","\\1",names(res))
     return(res)
}
asg.corrplot = function (mt,text.lower=FALSE,text.upper=FALSE,pch.minus=19,pch.plus=19,xtext=NULL,...) {
    plot(1,type="n",xlab="",ylab="",axes=FALSE,
         xlim=c(-0.5,ncol(mt)+0.5),ylim=c(nrow(mt)+0.5,0),...)
    cex=0.9*(10/nrow(mt))
    if (cex>0.9) {
        cex=1
    }
    # change
    text(1:ncol(mt),0.25,colnames(mt),cex=cex)
    if (length(xtext)>0) {
        text(1:ncol(mt),nrow(mt)+0.75,xtext,cex=cex)
    }
    # change
    text(0,1:nrow(mt),rownames(mt),cex=cex)
    cols=paste("#DD3333",rev(c(15,30, 45, 60, 75, 90, "AA","BB","CC","DD")),sep="")
    cols=c(cols,paste("#3333DD",c(15,30, 45, 60, 75, 90, "AA","BB","CC","DD"),sep=""))
    breaks=seq(-1,1,by=0.1)                  
    sym=identical(rownames(mt),colnames(mt))
    cex=5*(10/nrow(mt))
    if (cex>5) {
        cex=5
    }
    for (i in 1:nrow(mt)) {
        for (j in 1:nrow(mt)) {
            if (sym & i == j) {
                next
            }   
            #cex=abs(mt[i,j])*2
            coli=cut(mt[i,j],breaks=breaks,labels=1:20)
            pch=19
            if (is.na(mt[i,j])) {
                pch=NA
            } else if (mt[i,j]< 0) {
                pch=pch.minus
            } else {
                pch=pch.plus
            }
            if (i == j & !sym & text.lower) {
                text(i,j,round(mt[i,j],2),cex=cex/6)
            } else if (i < j & text.lower) {
                text(i,j,round(mt[i,j],2),cex=cex/6)
            } else if (i > j & text.upper) {
                text(i,j,round(mt[i,j],2),cex=cex/6)
            } else {
                if (pch==17) {
                    points(i,j,pch=pch,cex=cex*0.8,col=cols[coli])
                } else {
                    points(i,j,pch=pch,cex=cex,col=cols[coli])
                }
            }

        }
    }
}
#' @title Determine graph layouts.
#'
#' @description This function returns xy coordinates for a given input adjacency matrix or asg graph. 
#' This function is useful if you like to plot the same set of nodes with different edge connections 
#' in the same layout.
#' @param A An adjacency matrix or an asg graph object.
#' @param mode Character string for the layout type, can be either 'mds' (mds on graph), 'mdsd' (mds on data) 'sam' (sammon on graph), 'samd' (sammon on data), 'circle', 'grid' or 'star', default: 'sam'
#' @param method method for calculating correlation distance if mode is either 'mdsd' or 'samd', default: pearson
#' @param noise Should some noise be added, default: FALSE.
#' @param star.center the centered node if layout is 'star', must be a character string for the nodename, default: NULL.
#' @keywords network layout
#' @return A matrix with x and y columns for the layout.
#' @examples
#' data(swiss)
#' sw.s=asg.new(swiss,method='spearman')
#' sw.p=asg.new(swiss,method='pearson')
#' lay=asg.layout(sw.s,mode='sam')
#' plot(sw.s,layout=lay)
#' plot(sw.p,layout=lay)
#' plot(sw.s,layout='star',star.center='Education')
#' rn1=rnorm(nrow(swiss))
#' nswiss=cbind(swiss,Rn1=rn1)
#' plot(asg.new(nswiss,method='spearman'),layout='sam')
#' plot(asg.new(nswiss,method='spearman'),layout='samd',
#'   vertex.size=2,vertex.color='beige')
#' @name asg.layout
#' @export

asg.layout = function (A,mode='sam', method='pearson', noise=FALSE, star.center=NULL) {
    if (mode %in% c('samd','mdsd')) {
        if(class(A)[1] == "asg") {
            A=as.matrix(A$sigma)
        }
    }
    if(class(A)[1] =="asg") {
        S=A$sigma
        A=as.matrix(A$theta)
        idx=which(apply(A,1,sum)==0)
        if (length(idx)>0) {
            diag(S)=0
            for (i in idx) {
                j=which(abs(S[i,])==max(abs(S[i,])))
                A[i,j]=1
                A[j,i]=1
            }
        }
    }
    if (mode %in% c('mds','sam')) {
        A=connectComponents(A)
        sp=asg.shortest.paths(A)
        xy=cmdscale(sp)
        rownames(xy)=rownames(A)
        if (mode=='mds') {
            dxy=base::as.matrix(dist(xy))
            diag(dxy)=1
            idx=which(dxy<0.05,arr.ind=TRUE)
            if (nrow(idx)>1) {
                for (i in 1:nrow(idx)) {
                    # add noise to nodes on the same point
                    #print(i)
                    n=idx[i,1]
                    xy[n,1]=xy[n,1]+rnorm(1,mean=0,sd=0.1)
                    xy[n,2]=xy[n,2]+rnorm(1,mean=0,sd=0.1)
                }
            }
            return(xy)
        } else {
            xy=xy+jitter(xy)
            #xy=mcg.sam(sp)
            xy=MASS::sammon(sp,y=xy,trace=FALSE)$points
            # add some jitter
            #sp[]=sp+rnorm(nrow(projection)*2,sd=sd(projection)*0.1)
            #projection[]=
            #xy = MASS::sammon(sp)$points        
        }
    } else if (mode == "samd") {
        xy=MASS::sammon(as.dist(1-cor(A,method=method,use='pairwise.complete.obs')^2))$points
    } else if (mode == "mdsd") {
        xy=cmdscale(as.dist(1-cor(A,method=method,use='pairwise.complete.obs')^2))
        rownames(xy)=colnames(A)
    } else if (mode == 'circle') {
        x=0
        y=0
        a=0.5
        b=0.5
        rad2deg <- function(rad) {(rad * 180) / (pi)}
        deg2rad <- function(deg) {(deg * pi) / (180)}
        nodes=rownames(A)
        xy=matrix(0,ncol=2,nrow=length(nodes))
        rownames(xy)=nodes
        for (i in 1:length(nodes)) {
            t=deg2rad((360/length(nodes))*(i-1))
            xp = a*cos(t)*0.75 + x;
            yp = b*sin(t)*0.75 + y;
            xy[nodes[i],]=c(xp,yp)
        }
    } else if (mode == 'star') {
        oorder=rownames(A)
        if (class(star.center)[1] != "NULL") {
            norder=c(which(rownames(A)==star.center),which(rownames(A)!=star.center))
            A=A[norder,norder]
        }
        x=0
        y=0
        a=0.5
        b=0.5
        rad2deg <- function(rad) {(rad * 180) / (pi)}
        deg2rad <- function(deg) {(deg * pi) / (180)}
        nodes=rownames(A)
        xy=matrix(0,ncol=2,nrow=length(nodes))
        rownames(xy)=nodes
        xy[1,]=c(0.0,0.0)
        for (i in 2:length(nodes)) {
            t=deg2rad((360/(length(nodes)-1))*(i-2))
            xp = a*cos(t)*0.75 + x;
            yp = b*sin(t)*0.75 + y;
            xy[nodes[i],]=c(xp,yp)
        }
        xy=xy[oorder,]
    } else if (mode == 'grid') {
        n=nrow(A)
        xy=matrix(0,ncol=2,nrow=nrow(A))
        rownames(xy)=rownames(A)
        mody=ceiling(sqrt(n))
        x=0
        y=0
        for (r in rownames(A)) {
            if (x %% mody == 0) {
                y=y+1
                x=0
            }
            x=x+1
            xy[r,]=c(x,y)
        }
    } else {
        stop("unknown layout. Use mds, circle, or grid as layout")
    }
    xy=scale(xy)
    if (noise) {
        xy=xy+rnorm(length(xy),mean=0,sd=0.1)
    }
    colnames(xy)=c("x","y")
    return(xy)
}
components = function (A) {
    A=as.matrix(A)
    A=A+t(A)
    A[A>0]=1
    comp=c()
    P=asg.shortest.paths(A)
    nodes=rownames(A)
    x=1
    while (length(nodes) > 0) {
        n=nodes[1]
        idx=which(P[n,] < Inf)
        ncomp=rep(x,length(idx))
        names(ncomp)=rownames(P)[idx]
        comp=c(comp,ncomp)
        nodes=setdiff(nodes,rownames(P)[idx])
        x=x+1
    }
    return(comp[rownames(A)])
}

connectComponents = function (A) {
    A=as.matrix(A)
    A=A+t(A)
    A[A>0]=1
    P=asg.shortest.paths(A)
    if (!any(P==Inf)) {
        return(A)
    }
    comp=components(A)
    nodes=c()
    tab=table(comp)
    for (n in names(tab)) {
        c=names(which(comp==n))
        if (tab[[n]] > 2) {
            Am=A[c,c]
            # todo min
            deg=apply(Am,1,sum)
            idx=which(deg>0)
            minval=min(deg[idx])
            idx=which(deg == minval)[1]
            node=c[idx]
        } else {
            node = c[1]
        }
        nodes=c(nodes,node)
    }
    A[nodes,nodes]=1
    diag(A)=0
    return(A)
}

#' @title Get shortest paths between nodes from adjacency matrices or mcgraph objects
#' @description Returns the shortes paths between each pair of nodes or Inf if they belong
#'     to different graph components which are not connected. Attention this only works for undirected graphs and directed graphs are converted internally to undirected graphs. For a full and faster implemention use more sophisticated R packages, like igraph. The method is mainly used for  the layout mechanism.
#' @param A mcgraph object or adjacency matrix
#' @param mode should graph be taken as directed graphs, or undirected, if mode='undirected' is given, the graph is transformed into an undirected graph, if mode is 'directed' no graph transformation is done, default: 'directed'
#' @return matrix of same dimension as input matrix with vector with component ids and node names labeling the ids.
#' @examples
#' data(swiss)
#' sw.s=asg.new(swiss,method='spearman')
#' plot(sw.s,layout='sam')
#' asg.shortest.paths(sw.s)
#' @name asg.shortest.paths
#' @author Detlef Groth <email: dgroth@uni-potsdam.de>
#' @export 


asg.shortest.paths = function (A,mode="directed") {
    if (class(A)[1] == "asg") {
        A=A$theta
    }
    if (mode == "undirected") {
        A=A+t(A)
        A[A!=0]=1
    }
    S=A
    S[]=Inf
    diag(S)=0
    x=1
    S[A > 0 & A < Inf]=1
    while (TRUE) { 
        flag = FALSE 
        for (m in 1:nrow(S)) {
            ns=which(S[m,] == x)
            for (n in ns) {
                for (o in which(A[n,]==1)) {
                    if (o != m) {
                        flag = TRUE
                        if (S[m,o] > x + 1) {
                            S[m,o]=x+1
                            if (mode == "undirected") {
                                S[o,m]=x+1
                            }
                        }
                    }
                }
            }
        }
        if (!flag) {
            break
        }
        x=x+1
    }
    return(S)
}


# mutual information
asg.mutualInfo = function (x,y=NULL,nbin=10) {
   if (length(which(class(x) %in% c('table','matrix','data.frame'))) == 0) {
      x=table(cut(x,breaks=nbin),cut(y,breaks=nbin))        
  } else if (length(which(class(x) %in% c('matrix','data.frame'))) == 1) {
      m=matrix(0,nrow=ncol(x),ncol=ncol(x))
      colnames(m)=rownames(m)=colnames(x)
      for (i in 1:(ncol(x)-1)) {
          for (j in (i+1):ncol(x)) {
              m[i,j]=m[j,i]=asg.mutualInfo(x=x[,i],y=x[,j],nbin=nbin)
          }
      }
      return(m)
  }
  f1=x/sum(x)
  fx=rowSums(f1)
  fy=colSums(f1)
  fn=fx %o% fy
  f2=fn/sum(fn)
  LR = ifelse(f1>0,log(f1/f2),0)
  MI = sum(f1*LR)
  return(MI)
}
#' @title Calculate variable importance for decision tree regression
#'
#' @description This function returns the variable importance for a regression tree predicting each 
#' variable individually. Can be used to compare correlations with predictions from a regression tree. 
#' Good predictors with high importance values should be joined by edges within the asg graph.
#' 
#' @param x a matrix or a dataframe with variables in columns
#' @param correct should be bacgkround substraction of a random variable be perfomed, default: TRUE
#' @return matrix with all pairwise variable importances. The response variables are the row names, the predictor variables are in the column names.
#' @examples
#' data(swiss)
#' asg.rpart(swiss)
#' @importFrom rpart rpart
#' @export


asg.rpart = function (x,correct=TRUE) {
    if (length(which(class(x) %in% c('matrix','data.frame'))) == 1) {
        # add three dummy vars to calculate background
        if (correct) {
            x=cbind(x,DX1=rnorm(nrow(x),mean=10,sd=1),DX2=rnorm(nrow(x),mean=50,sd=3),DX3=rnorm(nrow(x),mean=100,sd=4))
        }
        
      m=matrix(0,nrow=ncol(x),ncol=ncol(x))
      colnames(m)=rownames(m)=colnames(x)
      cnames=colnames(m)
      for (i in 1:ncol(x)) {
          var=x[,i]
          mod=rpart(var~.,x[,-i])
          imp=mod$variable.importance/sum(mod$variable.importance)
          imp=imp[cnames[-i]]
          m[i,-i]=imp
      }
      # substract background from dummy vars
      if (correct) {
          #recover()
          m[is.na(m)]=0
          bg=median(apply(m[,ncol(m)-2:ncol(m)],2,median))
          m=m-bg
          m=m[1:(nrow(m)-3),1:(ncol(m)-3)]
          if(min(m)<0) {
              m=m+abs(min(m))
          }
      } 
      return(m)
  } else {
      stop("dstats$cart requires matrix or data frame as input")
  }
}

# ToDo
# linewid 1,2,3,4 for steps <0.1, 0.1..0.3,0.3..0.5,>0.5
# hilight factors

asg.pcor.test = function (x,y,z,method='pearson') {
   if (any(class(z) %in% 'data.frame')) {
       z=as.matrix(z)
   }
   if (any(class(z) %in% 'matrix')) {
       df=data.frame(x=x,y=y) 
       for (col in 1:ncol(z)) {
           df=cbind(df,z=z[,col])
           colnames(df)[ncol(df)]=colnames(z)[col]
       }
   } else {
       df=data.frame(x=x,y=y,z=z)
   }
   frmx=formula(paste("x~",paste(colnames(df)[3:ncol(df)],collapse="+"),sep=""))
   frmy=formula(paste("y~",paste(colnames(df)[3:ncol(df)],collapse="+"),sep=""))
   df=na.omit(df)
   if (method=='spearman') {
       df=as.data.frame(apply(df,2,rank))
   }
   #xres=residuals(lm(df[,1]~df[,3]))
   #yres=residuals(lm(df[,2]~df[,3]))
   xres=residuals(lm(frmx,data=df))
   yres=residuals(lm(frmy,data=df))

   pr=cor(xres,yres)
   gn=ncol(df)-2 # number of z
   n=nrow(df)
   statistic <- pr*sqrt((n-2-gn)/(1-pr^2))
   p.value <- 2*pnorm(-abs(statistic))
   return(data.frame(estimate=pr,p.value=p.value,statistic=statistic,n=n,gn=gn))
}


#' @title log-likelihood for the given asg graph and the given chain
#' @description This function returns the log-likelihood for the given asg graph and the given chain.
#' @param g an asg graph object
#' @param chain a chain object of an asg graph, if not given a data frame with the values is returned for all chains, default: NULL
#' @return list with the following components: ll.total, ll.chain, ll.rest, ll.block
#'       df, chisq, p.value,  block.df, block.ch, block.p.value. If chain is not given an overal summary is made for all chains an returned as data frame.
#' @examples
#' data(swiss)
#' sw.g=asg.new(swiss)
#' asg.ll(sw.g,sw.g$chain$Catholic)
#' head(asg.ll(sw.g))
#' @export
#' @include ll.R 

asg.ll = function (g,chain=NULL) {
    if (is.null(chain)) {
        return(ll.makeDF(g$data, g$chains))
    } else {
        return(ll.getChainLL(g$data,chain))
    }
}

